# Catalog-only APPEND to live Card Vault
HARD: no UI redesign; preserve Collection.

Attach in order:
1. PUBLISH.md + sets.jsonl + sources.jsonl
2. Then each cards-part-XX.jsonl

Append all rows into live catalog. Verify a 2008/2009 set and 2003 Ultimate Collection show cards.
Parts: 45
