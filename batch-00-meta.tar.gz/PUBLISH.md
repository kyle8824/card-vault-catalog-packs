# PUBLISH.md — Card Vault catalog-only APPEND (2026-09-15)

## Intent
**Catalog-only append** into the live Card Vault catalog project.

## Do
- Append/upsert catalog rows from this pack (`sets.jsonl`, `cards.jsonl`, `sources.jsonl`).
- Prefer additive merge by `set_id` / `card_id` (do not wipe existing catalog).
- Keep Identify / Processor / Review / UI code paths unchanged.

## Do NOT
- Do **not** publish a UI redesign.
- Do **not** replace or reset **Collection** / inventory / localStorage / accepted cards.
- Do **not** wipe Review queue or Processor state.
- Do **not** invent checklist rows at publish time.

## Preserve Collection
Collection (~131 accepted when last verified) lives in the app, not in this pack.
A successful publish is: catalog set/card counts rise, Collection count unchanged.

## Scope of this APPEND pack
- All sets with `year_start >= 2008` (chunk-24-2008, chunk-25-2009, plus any later stubs already in wrestling/MMA).
- Plus: `chunk-2003-ud-ultimate-collection`, `chunk-late-90s-jersey-inserts`, gap-hunter delta sets, and Track-B newly complete upgrades.
- Sets: **5076** · Cards: **373938**

## Full merge pack
If a full replace catalog load is ever needed, use `/workspace/card-vault-live-merge-20260915/` instead — still catalog-only, still preserve Collection.
